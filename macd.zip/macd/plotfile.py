#  -*- coding: utf-8 -*-

"""
普量学院量化投资课程系列案例源码包
普量学院版权所有
仅用于教学目的，严禁转发和用于盈利目的，违者必究
©Plouto-Quants All Rights Reserved

普量学院助教微信：niuxiaomi3
"""
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

from matplotlib.patches import Patch
from matplotlib.lines import Line2D
import itertools

plt.rcParams['font.family'] = 'sans-serif'
plt.rcParams['font.sans-serif'] = 'SimHei'
df = pd.read_excel('d:/2018-2019年空气质量均值.xlsx')
df2 = pd.read_excel('d:/2018-2019年空气质量均值.xlsx', 1)

width = 0.35  # the width of the bars: can also be len(x) sequence

citys = df2['城市名'].unique()

colNames = ["二氧化硫", "氮氧化物", "烟尘", "烟尘_"]
dictCol = {"二氧化硫": 'SO2', "氮氧化物": 'NO2', "烟尘": 'PM25', "烟尘_": 'PM10'}

regionTypes = ["省辖市", "市辖区"]

df2.set_index('城市名', inplace=True)


def getPlot(city, colName, regionType):
    colName2 = dictCol[colName]
    print(city, colName, regionType, colName2)
    colName = colName.strip('_')
    df = df2.loc[city]
    df.reset_index(inplace=True)
    df.sort_values('月份')
    fig, ax = plt.subplots(figsize=(10, 6))
    labels = df.月份.map(lambda x: str(x) + '月')
    y1 = df['2018年%s_%s' % (colName, regionType)].apply(round)

    y2 = df['2019年%s_%s' % (colName, regionType)].apply(round)

    x = np.arange(len(labels))  # the label locations
    rects1 = ax.bar(x - width / 2.0, y1, width, label='2018年%s排放量' % colName, color="tab:brown")

    rects2 = ax.bar(x + width / 2.0, y2, width, label='2019年%s排放量' % colName, color="tab:red")

    ax.set_ylabel('吨')

    title = '%s2018-2019年%s排放和%s监测值对比(%s)' % (city, colName, colName2, regionType)
    ax.set_title(title)
    ax.set_xticks(x)
    ax.set_xticklabels(labels)

    def autolabel(rects):
        """Attach a text label above each bar in *rects*, displaying its height."""
        for rect in rects:
            height = rect.get_height()
            ax.annotate('{}'.format(height),
                        xy=(rect.get_x() + rect.get_width() / 2, height),
                        xytext=(0, 3),  # 3 points vertical offset
                        textcoords="offset points",
                        ha='center', va='bottom')

    autolabel(rects1)
    autolabel(rects2)

    ax2 = plt.twinx()

    ax2.set_ylabel('微克/立方米')
    ymax = np.max([df[colName2 + '_2018年'].max(), df[colName2 + '_2019年'].max()]) * (1 + 0.1)
    ax2.set_ylim(bottom=0, top=ymax)
    p1 = ax2.plot(df[colName2 + '_2018年'], color="brown")
    p2 = ax2.plot(df[colName2 + '_2019年'], color="red")
    ax2.yaxis.set_tick_params(direction='out')

    print(colName2)
    legend_elements = [

        Patch(facecolor='tab:brown', edgecolor='b', label='2018年%s排放量' % colName),

        Patch(facecolor='tab:red', edgecolor='b', label='2019年%s排放量' % colName),
        Line2D([0], [0], color='brown', lw=2, label='2018年%s监测值' % colName2),
        # Line2D([0], [0], marker='o', color='w', label='Scatter', markerfacecolor='g', markersize=15),
        Line2D([0], [0], color='red', lw=2, label='2019年%s监测值' % colName2),

    ]

    ax.legend(handles=legend_elements, loc='best')
    plt.savefig(title + '.png')
    plt.close()


for city, colName, regionType in itertools.product(citys, colNames, regionTypes):
    if ((city == '济源市') & (regionType == '市辖区')):
        continue
    print(city, colName, regionType)
    getPlot(city, colName, regionType)