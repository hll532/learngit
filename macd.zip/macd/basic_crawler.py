#  -*- coding: utf-8 -*-

"""
普量学院量化投资课程系列案例源码包
普量学院版权所有
仅用于教学目的，严禁转发和用于盈利目的，违者必究
©Plouto-Quants All Rights Reserved

普量学院助教微信：niuxiaomi3
"""
import time
from datetime import datetime, timedelta

import tushare as ts
from pymongo import UpdateOne

from database import DB_CONN
from stock_util import get_trading_dates

"""
从tushare获取股票基础数据，保存到本地的MongoDB数据库中
"""


def crawl_basic(begin_date=None, end_date=None):
    """
    抓取指定时间范围内的股票基础信息
    :param begin_date: 开始日期
    :param end_date: 结束日期
    """

    # 如果没有指定开始日期，则默认为前一日
    if begin_date is None:
        begin_date = (datetime.now() - timedelta(days=1)).strftime('%Y%m%d')

    # 如果没有指定结束日期，则默认为前一日
    if end_date is None:
        end_date = (datetime.now() - timedelta(days=1)).strftime('%Y%m%d')

    # 获取指定日期范围的所有交易日列表
    all_dates = get_trading_dates(begin_date, end_date)
    print(all_dates)


    #all_dates = get_trading_dates('20190101', '20190102'),

    # 按照每个交易日抓取
    i=0
    for date in all_dates:
        try:
            i += 1
            print('指数总数=')
            print(len(all_dates))
            print('剩余次数=')
            print(len(all_dates) - i)
            # 抓取当日的基本信息
            print('date')
            print(date)
            crawl_basic_at_date(date)
        except:
            print('抓取股票基本信息时出错，日期：%s' % date, flush=True)
            #time.sleep(5)
            #continue


def crawl_basic_at_date(date):
    """
    从Tushare抓取指定日期的股票基本信息
    :param date: 日期
    """
    # 从TuShare获取基本信息，index是股票代码列表
    pro = ts.pro_api()
    print('begin..')
    print(date)
    #df_basics = ts.get_stock_basics(date)
    df_basics = pro.stock_basic(exchange='', list_status='L', fields='ts_code,symbol,name,area,industry,list_date')
    df_daily_basics = pro.daily_basic(ts_code='', trade_date=date,
                                      fields='ts_code,trade_date,turnover_rate,volume_ratio,pe,pb,total_share,float_share')

    df_basics=df_basics.set_index(keys=['ts_code'])
    df_daily_basics = df_daily_basics.set_index(keys=['ts_code'])
    print('df_basics')
    print(df_basics)
    print('df_daily_basics')
    print(df_daily_basics)


    # 如果当日没有基础信息，在不做操作
    if df_basics is None:
        return
    if df_daily_basics is None:
        return

    # 初始化更新请求列表
    update_requests = []
    # 获取所有股票代码集合

    #df_basics_codes = df_basics.drop_duplicates(subset=['ts_code'], keep='first', inplace=False)

    #df_basics_codes.set_index('ts_code')
    #codes = set(df_basics_codes.ts_code)

    # 按照股票代码提取所有数据
    i=0
    codes = df_basics.index
    codes=['000001.SZ','000002.SZ']

    #for code in df_basics.index:
    for code in codes:
        i += 1
        print('指数总数=')
        print(len(codes))
        print('剩余次数=')
        print(len(codes) - i)
        print('df_basics.loc[code]')
        print(df_basics.loc[code])
        print('code')
        print(code)
        df_basics_code = df_basics.loc[code]
        df_basic_dict = df_basics_code.to_dict()
        print('code101')
        try:
            df_daily_basics_code = df_daily_basics.loc[code]
            df_basics_code_dict = df_daily_basics_code.to_dict()

            print('code104')






        # 获取一只股票的数据
            doc = df_basic_dict
            print('doc...')
            print(doc)
        #doc1_old = dict(df_basics_code)
            doc1 = df_basics_code_dict
            print('doc1...')
            print(doc1)
        except:
            print('error126..')
            pass
        #doc1 = dict(df_basic)



        #print(doc['list_date'].values)
        #print(str(doc['list_date'].values))
            print('docok')
        try:
            # 将上市日期，20180101转换为2018-01-01的形式
            #time_to_market = datetime \
                #.strptime(str(doc['list_date']), '%Y%m%d') \
                #.strftime('%Y%m%d')
            print('list_date')
            print(str(doc['list_date']))
            #print('timestr')
            timetest = doc['list_date']
            #timetest = doc['list_date'].values[0]
            time_to_market = datetime.strptime(str(timetest) ,'%Y%m%d').strftime('%Y%m%d')
            print(time_to_market)
            #time_to_market = doc['list_date'].values
            #strtimeto = ''.join(time_to_market)qQ
            #print(strtimeto)
            #print('strtime...')
            #time_to_market = datetime.strptime(str(doc['list_date'].values), '%Y%m%d')
            #print(time_to_market)
           # print('timetomarket')
            #print(doc1)
            print('doc1total....')

            # 将总股本和流通股本转为数字
            totals = float(doc1['total_share'])
            print(totals)
            outstanding = float(doc1['float_share'])
            print(outstanding)
            print('outstanding....')

            # 组合成基本信息文档
            doc.update({
                # 股票代码
                'ts_code': code,
                # 日期
                'trade_date': date,
                # 上市日期
                'list_date': time_to_market,
                # 流通股本
                'float_share': outstanding,
                # 总股本
                'total_share': totals
            })
            print('doc151')
            print(doc)

            # 生成更新请求，需要按照code和date创建索引

            #print(date)
            print('update...')
            update_requests.append(
                UpdateOne(
                    {'ts_code': code, 'trade_date': date}, {'$set': doc}, upsert=True))
                    #{'$set': doc}, upsert=True))
            print('len(update_requests)')
            print(len(update_requests))
            print(update_requests)
            update_result_db = DB_CONN['basic']
            print('update177...')
            update_result = update_result_db.bulk_write(update_requests, ordered=False)
            print('update_requests')

            #print(update_requests)

        except:
            print('发生异常，股票代码：%s，日期：%s' % (code, date), flush=True)
            print('len(update_requests)')
            print(len(update_requests))
            time.sleep(5)
            continue
            #print(doc, flush=True)

    # 如果抓到了数据
    if len(update_requests) > 0:
        print('len(update_requests)162')
        print(len(update_requests))
        update_result_db = DB_CONN['basic']
        print('len(update_requests)169')
        update_result = update_result_db.bulk_write(update_requests, ordered=False)
        #update_result = collection.bulk_write(update_requests, ordered=False)
        print('抓取股票基本信息，日期：%s, 插入：%4d条，更新：%4d条' %
              (date, update_result.upserted_count, update_result.modified_count), flush=True)


if __name__ == '__main__':
    crawl_basic('20210118', '20220118')
