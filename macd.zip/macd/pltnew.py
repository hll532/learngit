#  -*- coding: utf-8 -*-

"""
普量学院量化投资课程系列案例源码包
普量学院版权所有
仅用于教学目的，严禁转发和用于盈利目的，违者必究
©Plouto-Quants All Rights Reserved

普量学院助教微信：niuxiaomi3
"""


import matplotlib

matplotlib.use('Agg') #控制绘图不显示

import numpy as np

import pandas as pd

#关于import这些玩意，请使用 sudo apt install python-XXX

import matplotlib.pyplot as plt

from matplotlib import mlab

from matplotlib import rcParams

def pltpic(DIFF_plt, DEA_plt, close_plt, trade_date_plt, delta_plt,code,cgl):


    #print('vbar1')
    #print(type(delta_plt))
    fig, ax1 = plt.subplots(figsize=(15,10))
#subplots() 既创建了一个包含子图区域的画布，又创建了一个 figure 图形对象，而 subplot() 只是创建一个包含子图区域的画布。
    x=np.arange(len(trade_date_plt))

    y=np.array(list(delta_plt))

    #w=np.array(list(vbar2))

    xticks1=list(trade_date_plt)

#条形图

#plt.bar(x[0:6],y[0:6],width = 0.45,align='center',color = 'gray',alpha=0.9)

#plt.bar(x[6:],y[6:],width = 0.45,align='center',color = 'c',alpha=0.9)

#上面这两条语句，是用来设置条形图的颜色的，前6条柱子是gray色，而后四条是蓝绿色

    plt.bar(x,y,width = 0.45,label='female',align='center',color = 'b',alpha=0.9)

    #plt.bar(x,w,bottom=vbar1,label='male',tick_label=vbar1,width = 0.45,align='center',color = 'y',alpha=0.9)

#看我斜体数据，就是关键了

    plt.xticks(x,xticks1,size='medium')

#打印下方条形图的数据

    for a,b in zip(x,y):

        plt.text(a, b, '%s' % b, ha='center', va= 'bottom',fontsize=0)

#折线图

    ax2 = ax1.twinx()

    z=np.array(list(DIFF_plt))

    ax2.plot(x,z,c='r',marker='o')

#打印折线图的数据

    for a,b in zip(x,z):

        plt.text(a, b, '%s' % b, ha='center', va= 'bottom',fontsize=0)

        # 折线图

    ax3 = ax1.twinx()

    z1 = np.array(list(DEA_plt))

    ax3.plot(x, z1, c='g', marker='o')

        # 打印折线图的数据

    for a, b in zip(x, z1):
        plt.text(a, b, '%s' % b, ha='center', va='bottom', fontsize=0)


        # 折线图

    ax4 = ax1.twinx()

    z2 = np.array(list(close_plt))

    ax4.plot(x, z2, c='y', marker='o')

        # 打印折线图的数据

    for a, b in zip(x, z2):
        plt.text(a, b, '%s' % b, ha='center', va='bottom', fontsize=0)

#保存成图片
    name='./img/'+str(code)+'.png'
    #title='成功概率：'+ str(cgl)
    ax1.set_title(cgl,fontsize=12,color='r')
    plt.savefig(name,format='png')



