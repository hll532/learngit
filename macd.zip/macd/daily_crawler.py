#  -*- coding: utf-8 -*-

"""
普量学院量化投资课程系列案例源码包
普量学院版权所有
仅用于教学目的，严禁转发和用于盈利目的，违者必究
©Plouto-Quants All Rights Reserved

普量学院助教微信：niuxiaomi3
"""

from pymongo import UpdateOne
from database import DB_CONN
import tushare as ts
from datetime import datetime
import time

"""
从tushare获取日K数据，保存到本地的MongoDB数据库中
"""


class DailyCrawler:
    def __init__(self):
        """
        初始化
        """
        print('step27...')
        #time.sleep(10)
        ts.set_token('accdf4fb571b2b99c24fd19a4cbb67edc73e1d3a95cb3ca7a437dec1')
        # 创建daily指数数据集
        self.daily_zs = DB_CONN['daily_zs']
        # 创建daily数据集
        self.daily = DB_CONN['daily']
        self.daily_kzz = DB_CONN['daily_kzz']
        print('conn31..')
        # 创建daily_hfq数据集
        self.daily_hfq = DB_CONN['daily_hfq']
        self.daily_qfq = DB_CONN['daily_qfq']
        self.daily_basic = DB_CONN['daily_basic']
        self.daily_collection =DB_CONN['daily_collection']
        #复权因子
        self.daily_fqyz = DB_CONN['daily_fqyz']
        #pe


    def crawl_index(self, begin_date=None, end_date=None):
        """
        抓取指数的日K数据。
        指数行情的主要作用：
        1. 用来生成交易日历
        2. 回测时做为收益的对比基准

        :param begin_date: 开始日期
        :param end_date: 结束日期
        """

        # 指定抓取的指数列表，可以增加和改变列表里的值
        index_codes = ['000001.SH', '000300.SH', '399001.SZ', '399005.SZ', '399006.SZ']

        # 当前日期
        now = datetime.now().strftime('%Y%m%d')
        # 如果没有指定开始，则默认为当前日期
        print(now)
        #time.sleep(20)
        if begin_date is None:
            begin_date = now

        # 如果没有指定结束日，则默认为当前日期
        if end_date is None:
            end_date = now

        # 按照指数的代码循环，抓取所有指数信息
        i = 0
        for code in index_codes:
            # 抓取一个指数的在时间区间的数据
            i+=1
            print('指数总数=')
            print(len(index_codes))
            print('剩余次数=')
            print(len(index_codes)-i)

            pro = ts.pro_api()
            df_daily = pro.index_daily(ts_code=code, start_date=begin_date, end_date=end_date)
            print('zs.code.......')
            print(code)


            #df_daily =ts.pro_bar(ts_code='000001.SH', adj='None', start_date='20190101', end_date='20190102')
            #df_daily = ts.pro_bar(ts_code=code, adj='None', start_date=begin_date, end_date=end_date)
            #df_daily = ts.get_k_data(code, index=True, start=begin_date, end=end_date)
            # 保存数据
            print('dfdaily')
            # df_daily = pro.index_daily(ts_code='000300.SH', start_date='20190101', end_date='20190131')
            print(df_daily)

            self.save_data(code, df_daily, self.daily_zs, {'index': True})

    def save_data(self, code, df_daily, collection, extra_fields=None):
        """
        将从网上抓取的数据保存到本地MongoDB中

        :param code: 股票代码
        :param df_daily: 包含日线数据的DataFrame
        :param collection: 要保存的数据集
        :param extra_fields: 除了K线数据中保存的字段，需要额外保存的字段
        """

        # 数据更新的请求列表
        update_requests = []

        # 将DataFrame中的行情数据，生成更新数据的请求
        i=0
        for df_index in df_daily.index:
            i += 1
            print('指数总数=')
            print(len(df_daily.index))
            print('剩余次数=')
            print(len(df_daily.index) - i)
            print(df_index)
            print('dfindex..')
            print(df_daily.loc[df_index])

            # 将DataFrame中的一行数据转dict
            doc = dict(df_daily.loc[df_index])
            print('docdc...')
            print(doc)

            # 设置股票代码
            doc['ts_code'] = code

            # 如果指定了其他字段，则更新dict
            if extra_fields is not None:
                doc.update(extra_fields)

            # 生成一条数据库的更新请求
            # 注意：
            # 需要在code、date、index三个字段上增加索引，否则随着数据量的增加，
            # 写入速度会变慢，创建索引的命令式：
            # db.daily.createIndex({'code':1,'date':1,'index':1})
            update_requests.append(
                UpdateOne(
                    {'ts_code': doc['ts_code'], 'trade_date': doc['trade_date'], 'index': doc['index']},
                    {'$set': doc},
                    upsert=True)
            )
            print(update_requests)
            print('update_requests')
            #time.sleep(20)

        # 如果写入的请求列表不为空，则保存都数据库中
        if len(update_requests) > 0:
            # 批量写入到数据库中，批量写入可以降低网络IO，提高速度
            update_result = collection.bulk_write(update_requests, ordered=False)
            print('保存日线数据，代码： %s, 插入：%4d条, 更新：%4d条' %
                  (code, update_result.upserted_count, update_result.modified_count),
                  flush=True)

    def crawl(self, begin_date=None, end_date=None):
        """
        抓取股票的日K数据，主要包含了不复权和后复权两种

        :param begin_date: 开始日期
        :param end_date: 结束日期
        """

        # 通过tushare的基本信息API，获取所有股票的基本信息
        print('step118...')
        pro = ts.pro_api()
        #stock_df = pro.daily_basic(ts_code='', trade_date='20180726',fields='ts_code,trade_date,turnover_rate,volume_ratio,pe,pb')
        #stock_df = ts.get_stock_basics()


        stock_df = pro.stock_basic(exchange='', list_status='L', fields='ts_code,symbol,name,area,industry,list_date')

        # 将基本信息的索引列表转化为股票代码列表
        print('step119...')
        #codes = list(stock_df.ts_code)

        stock_df_codes = stock_df.drop_duplicates(subset=['ts_code'], keep='first', inplace=False)
        codes = list(stock_df_codes.ts_code)
        codes=['000001.SZ','000002.SZ']
        print(codes)
        # 当前日期
        now = datetime.now().strftime('%Y%m%d')

        # 如果没有指定开始日期，则默认为当前日期
        if begin_date is None:
            begin_date = now

        # 如果没有指定结束日期，则默认为当前日期
        if end_date is None:
            end_date = now
        i=0
        for code in codes:
            i += 1
            print('指数总数=')
            print(len(codes))
            print('剩余次数=')
            print(len(codes) - i)
            # 抓取不复权的价格
            print(code)
            print('code...')
            try:
                df_daily = ts.pro_bar(ts_code=code, adj='None', start_date=begin_date, end_date=end_date)
                df_daily.index.name = 'index'
            #df_daily = ts.get_k_data(code, autype=None, start=begin_date, end=end_date)
                #df_daily = ts.pro_bar(ts_code='000001.SZ', adj='None', start_date='20180101', end_date='20181011')
            #df_daily = pro.daily(ts_code=code, start_date=begin_date, end_date=end_date)
            #df = ts.pro_bar(ts_code='000001.SZ', adj='qfq', start_date='20180101', end_date='20181011')
            #df_daily = ts.get_k_data('128093', autype=None, start='2019-01-01', end='2019-1-02')
                self.save_data(code, df_daily, self.daily, {'index': False})
                stock_df_daily = pro.daily_basic(ts_code=code, start_date=begin_date, end_date=end_date,
                                                 fields='ts_code,trade_date,close,turnover_rate,volume_ratio,'
                                                        'pe,pb,total_share,float_share,total_mv')
                stock_df_daily.index.name = 'index'
                self.save_data(code, stock_df_daily, self.daily_basic, {'index': False})



                print('hfq....')

            # 抓取后复权的价格
                df_daily_hfq = ts.pro_bar(ts_code=code, adj='hfq', start_date=begin_date, end_date=end_date)
                df_daily_hfq.index.name = 'index'
            #df_daily_hfq = ts.get_k_data(code, autype='hfq', start=begin_date, end=end_date)
                self.save_data(code, df_daily_hfq, self.daily_hfq, {'index': False})
                # 抓取后复权的价格
                df_daily_qfq = ts.pro_bar(ts_code=code, adj='qfq', start_date=begin_date, end_date=end_date)
                df_daily_hfq.index.name = 'index'
                # df_daily_hfq = ts.get_k_data(code, autype='hfq', start=begin_date, end=end_date)
                self.save_data(code, df_daily_qfq, self.daily_qfq, {'index': False})
                print('forlooping')
            # 抓取复权因子
                # 提取2018年7月18日复权因子
                df_daily_fqyz = pro.adj_factor(ts_code=code, start_date=begin_date, end_date=end_date)
                #df_daily_fqyz = ts.pro_bar(ts_code=code, adj='hfq', start_date=begin_date, end_date=end_date)
                df_daily_fqyz.index.name = 'index'
            #df_daily_hfq = ts.get_k_data(code, autype='hfq', start=begin_date, end=end_date)
                self.save_data(code, df_daily_fqyz, self.daily_fqyz, {'index': False})
                print('forlooping')

            except:
                print('error')
               # time.sleep(20)


                continue


# 抓取程序的入口函数
if __name__ == '__main__':
    dc = DailyCrawler()
    # 抓取指定日期范围的指数日行情
    # 这两个参数可以根据需求改变，时间范围越长，抓取时花费的时间就会越长
    dc.crawl_index('20210118', '20220118')
    print('指数日行情151...')
    # 抓取指定日期范围的股票日行情
    # 这两个参数可以根据需求改变，时间范围越长，抓取时花费的时间就会越长
    dc.crawl('20210118', '20220118')
    print('股票日行情155...')
