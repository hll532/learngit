#  -*- coding: utf-8 -*-

from selenium import webdriver
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait
import time
import pandas as pd
import os
from datetime import datetime
from stock_util import get_all_codes_cb
from database import DB_CONN
from pymongo import UpdateOne

chrome_options = webdriver.ChromeOptions()
chrome_options.add_argument('--headless')
browser = webdriver.Chrome(options=chrome_options)
# browser = webdriver.PhantomJS() # 会报警高提示不建议使用phantomjs，建议chrome添加无头
browser.maximize_window()  # 最大化窗口
wait = WebDriverWait(browser, 10)
lst_det_np = []
lst_det_jj = []
lst_det_zf = []
lst_det_zd = []
lst_det_zs = []
lst_det_je = []
lst_det_zhenf = []
lst_det_lb = []
lst_det_zg = []
lst_det_zuid = []
lst_det_jk = []
lst_det_zuos = []
lst_det_wp = []
lst_det_neip = []
lst_wb = []
lst_wc = []
lst_sell5_sell5 = []
lst_sell5_sell5_quant = []
lst_sell5_sell5_num = []
lst_sell5_sell4 = []
lst_sell5_sell4_quant = []
lst_sell5_sell4_num = []
lst_sell5_sell3 = []
lst_sell5_sell3_quant = []
lst_sell5_sell3_num = []
lst_sell5_sell2 = []
lst_sell5_sell2_quant = []
lst_sell5_sell2_num = []
lst_sell5_sell1 = []
lst_sell5_sell1_quant = []
lst_sell5_sell1_num = []

lst_sell5_buy5 = []
lst_sell5_buy5_quant = []
lst_sell5_buy5_num = []
lst_sell5_buy4 = []
lst_sell5_buy4_quant = []
lst_sell5_buy4_num = []
lst_sell5_buy3 = []
lst_sell5_buy3_quant = []
lst_sell5_buy3_num = []
lst_sell5_buy2 = []
lst_sell5_buy2_quant = []
lst_sell5_buy2_num = []
lst_sell5_buy1 = []
lst_sell5_buy1_quant = []
lst_sell5_buy1_num = []

lst_time_0 = []
lst_time_1 = []
lst_time_2 = []
lst_time_3 = []
lst_time_4 = []
lst_time_5 = []
lst_time_6 = []
lst_time_7 = []
lst_time_8 = []
lst_time_9 = []
lst_time_10 = []
lst_time_11 = []
lst_time_12 = []
lst_time_13 = []
lst_time_14 = []
lst_time_15 = []
lst_time_16 = []
lst_time_17 = []
lst_time_18 = []
lst_time_19 = []
lst_time_20 = []
lst_time_21 = []
lst_time_22 = []
lst_time_23 = []
lst_time_24 = []
lst_time_25 = []
lst_time_26 = []
lst_time_27 = []
lst_time_28 = []
lst_time_29 = []
lst_code = []
codes_cb=[]
codes = get_all_codes_cb()
print('codes_len==')
print(len(codes))
for code in codes :
    #print(code[:-3])
    #print(code[7:9])
    code_new=code[7:9]+code[:-3]
    #print(code_new)
    codes_cb.append(code_new)
print('code-cb===')
print(codes_cb)

codes = ['sh110038', 'sh110052']
now = datetime.now().strftime('%H%M')

while '0010' <= str(now) <= '2400':
    print('大于')

    print(now)

    for code in codes:
        try:
            url = 'http://quote.eastmoney.com/bond/' + code + '.html'
            wait = WebDriverWait(browser, 10)
            browser.get(url)
            print(url)
            # body > div:nth-child(7) > div.fr.side.side_right > div:nth-child(1) > div.info_list > table:nth-child(1)
            element = browser.find_element(By.CSS_SELECTOR, 'body > div:nth-child(7) >'
                                                            ' div.fr.side.side_right >'
                                                            ' div:nth-child(1) >'
                                                            ' div.info_list >'
                                                            ' table:nth-child(1)')
            td_content = element.find_elements(By.TAG_NAME, "td")  # 进一步定位到表格内容所在的td节点
            # print('row...')
            # print(len(td_content))
            # print(td_content)
            # 提取表格内容td
            # td_content = element.find_elements_by_tag_name("td")

            i = 0
            for td in td_content:
                i += 1
                # print('i==')
                # print(i % 2)
                t = i % 2
                # print(td.text) # str
                if t == 1:
                    txt = td.text
                    txtlist = txt.split(' ')
                    # print('txtlist')
                    # print(txtlist[1])
                    lst_wb.append(txtlist[1])
                if t == 0:
                    txt = td.text
                    txtlist = txt.split(' ')
                    # print('txtlist')
                    # print(txtlist[1])
                    lst_wc.append(txtlist[1])

            # print('wb.36..')

            ##sell_table#sell_table body > div:nth-child(7) > div.fr.side.side_right > div:nth-child(1) > div.info_list > table:nth-child(1)
            element = browser.find_element(By.CSS_SELECTOR, '#sell_table#sell_table')
            td_content = element.find_elements(By.TAG_NAME, "td")  # 进一步定位到表格内容所在的td节点
            # print('sell...')
            # print(len(td_content))
            # print(td_content)
            # 提取表格内容td
            # td_content = element.find_elements_by_tag_name("td")

            i = 0
            for td in td_content:
                i += 1
                divd = i % 15

                if divd == 1:
                    # print('sell5-1')

                    # print(td.text)
                    lst_sell5_sell5.append(td.text)
                elif divd == 2:
                    # print('sell5-2')

                    # print(td.text)
                    lst_sell5_sell5_quant.append(td.text)
                elif divd == 3:
                    # print('sell5-3')

                    # print(td.text)
                    lst_sell5_sell5_num.append(td.text)
                elif divd == 4:
                    # print('sell4-1')

                    # print(td.text)
                    lst_sell5_sell4.append(td.text)
                elif divd == 5:
                    # print('sell4-2')

                    # print(td.text)
                    lst_sell5_sell4_quant.append(td.text)
                elif divd == 6:
                    # print('sell4-3')

                    # print(td.text)
                    lst_sell5_sell4_num.append(td.text)
                elif divd == 7:
                    # print('sell3-1')

                    # print(td.text)
                    lst_sell5_sell3.append(td.text)
                elif divd == 8:
                    # print('sell3-2')

                    # print(td.text)
                    lst_sell5_sell3_quant.append(td.text)
                elif divd == 9:
                    # print('sell3-3')

                    # print(td.text)
                    lst_sell5_sell3_num.append(td.text)
                elif divd == 10:
                    # print('sell2-1')

                    # print(td.text)
                    lst_sell5_sell2.append(td.text)
                elif divd == 11:
                    # print('sell2-2')

                    # print(td.text)
                    lst_sell5_sell2_quant.append(td.text)
                elif divd == 12:
                    # print('sell2-3')

                    # print(td.text)
                    lst_sell5_sell2_num.append(td.text)
                elif divd == 13:
                    # print('sell1-1')

                    # print(td.text)
                    lst_sell5_sell1.append(td.text)
                elif divd == 14:
                    # print('sell1-2')

                    # print(td.text)
                    lst_sell5_sell1_quant.append(td.text)
                elif divd == 0:
                    # print('sell1-3')

                    # print(td.text)
                    lst_sell5_sell1_num.append(td.text)

            # print('sell0.68..')

            ##buy_table#buy_table
            element = browser.find_element(By.CSS_SELECTOR, '#buy_table#buy_table')
            td_content = element.find_elements(By.TAG_NAME, "td")  # 进一步定位到表格内容所在的td节点
            # print('row168...')

            # 提取表格内容td
            # td_content = element.find_elements_by_tag_name("td")

            i = 0
            for td in td_content:
                i += 1
                divd = i % 15

                if divd == 1:
                    # print('sell5-1')

                    # print(td.text)
                    lst_sell5_buy5.append(td.text)
                elif divd == 2:
                    # print('sell5-2')

                    # print(td.text)
                    lst_sell5_buy5_quant.append(td.text)
                elif divd == 3:
                    # print('sell5-3')

                    # print(td.text)
                    lst_sell5_buy5_num.append(td.text)
                elif divd == 4:
                    # print('sell4-1')

                    # print(td.text)
                    lst_sell5_buy4.append(td.text)
                elif divd == 5:
                    # print('sell4-2')

                    # print(td.text)
                    lst_sell5_buy4_quant.append(td.text)
                elif divd == 6:
                    # print('sell4-3')

                    # print(td.text)
                    lst_sell5_buy4_num.append(td.text)
                elif divd == 7:
                    # print('sell3-1')

                    # print(td.text)
                    lst_sell5_buy3.append(td.text)
                elif divd == 8:
                    # print('sell3-2')

                    # print(td.text)
                    lst_sell5_buy3_quant.append(td.text)
                elif divd == 9:
                    # print('sell3-3')

                    # print(td.text)
                    lst_sell5_buy3_num.append(td.text)
                elif divd == 10:
                    # print('sell2-1')

                    # print(td.text)
                    lst_sell5_buy2.append(td.text)
                elif divd == 11:
                    # print('sell2-2')

                    # print(td.text)
                    lst_sell5_buy2_quant.append(td.text)
                elif divd == 12:
                    # print('sell2-3')

                    # print(td.text)
                    lst_sell5_buy2_num.append(td.text)
                elif divd == 13:
                    # print('sell1-1')

                    # print(td.text)
                    lst_sell5_buy1.append(td.text)
                elif divd == 14:
                    # print('sell1-2')

                    # print(td.text)
                    lst_sell5_buy1_quant.append(td.text)
                elif divd == 0:
                    # print('sell1-3')

                    # print(td.text)
                    lst_sell5_buy1_num.append(td.text)

            # body > div:nth-child(7) > div.fr.side.side_right > div:nth-child(1) > div.box-x1.line24 > table
            element = browser.find_element(By.CSS_SELECTOR, 'body > div:nth-child(7) >'
                                                            ' div.fr.side.side_right >'
                                                            ' div:nth-child(1) >'
                                                            ' div.box-x1.line24 > table')
            td_content = element.find_elements(By.TAG_NAME, "td")  # 进一步定位到表格内容所在的td节点
            # print('row...')
            # print(len(td_content))
            # print(td_content)
            # 提取表格内容td
            # td_content = element.find_elements_by_tag_name("td")

            i = 0
            for td in td_content:
                i += 1
                # print('i==')
                # print(i % 2)
                t = i % 14
                # print(td.text) # str
                if t == 1:
                    txt = td.text
                    txtlist = txt.split('：')
                    # print('txtlist')
                    # print(txtlist[1])
                    lst_det_np.append(txtlist[1])
                elif t == 2:
                    txt = td.text
                    txtlist = txt.split('：')
                    # print('txtlist')
                    # print(txtlist[1])
                    lst_det_jj.append(txtlist[1])
                elif t == 3:
                    txt = td.text
                    txtlist = txt.split('：')
                    # print('txtlist')
                    # print(txtlist[1])
                    lst_det_zf.append(txtlist[1])
                elif t == 4:
                    txt = td.text
                    txtlist = txt.split('：')
                    # print('txtlist')
                    # print(txtlist[1])
                    lst_det_zd.append(txtlist[1])
                elif t == 5:
                    txt = td.text
                    txtlist = txt.split('：')
                    # print('txtlist')
                    # print(txtlist[1])
                    lst_det_zs.append(txtlist[1])
                elif t == 6:
                    txt = td.text
                    txtlist = txt.split('：')
                    # print('txtlist')
                    # print(txtlist[1])
                    lst_det_je.append(txtlist[1])
                elif t == 7:
                    txt = td.text
                    txtlist = txt.split('：')
                    # print('txtlist')
                    # print(txtlist[1])
                    lst_det_zhenf.append(txtlist[1])
                elif t == 8:
                    txt = td.text
                    txtlist = txt.split('：')
                    # print('txtlist')
                    # print(txtlist[1])
                    lst_det_lb.append(txtlist[1])
                elif t == 9:
                    txt = td.text
                    txtlist = txt.split('：')
                    # print('txtlist')
                    # print(txtlist[1])
                    lst_det_zg.append(txtlist[1])
                elif t == 10:
                    txt = td.text
                    txtlist = txt.split('：')
                    # print('txtlist')
                    # print(txtlist[1])
                    lst_det_zuid.append(txtlist[1])
                elif t == 11:
                    txt = td.text
                    txtlist = txt.split('：')
                    # print('txtlist')
                    # print(txtlist[1])
                    lst_det_jk.append(txtlist[1])
                elif t == 12:
                    txt = td.text
                    txtlist = txt.split('：')
                    # print('txtlist')
                    # print(txtlist[1])
                    lst_det_zuos.append(txtlist[1])
                elif t == 13:
                    txt = td.text
                    txtlist = txt.split('：')
                    # print('txtlist')
                    # print(txtlist[1])
                    lst_det_wp.append(txtlist[1])
                elif t == 0:
                    txt = td.text
                    txtlist = txt.split('：')
                    # print('txtlist')
                    # print(txtlist[1])
                    lst_det_neip.append(txtlist[1])

            # print('det.68..')

            ##deal_detail
            element = browser.find_element(By.CSS_SELECTOR, '#deal_detail')
            td_content = element.find_elements(By.TAG_NAME, "td")  # 进一步定位到表格内容所在的td节点

            # 提取表格内容td
            # td_content = element.find_elements_by_tag_name("td")
            i = 0
            for td in td_content:
                i += 1
                t = i % 30
                # print(td.text) # str
                if t == 1:

                    lst_time_1.append(td.text)
                elif t == 2:

                    lst_time_2.append(td.text)
                elif t == 3:

                    lst_time_3.append(td.text)
                elif t == 4:

                    lst_time_4.append(td.text)
                elif t == 5:

                    lst_time_5.append(td.text)
                elif t == 6:

                    lst_time_6.append(td.text)
                elif t == 7:

                    lst_time_7.append(td.text)
                elif t == 8:

                    lst_time_8.append(td.text)
                elif t == 9:

                    lst_time_9.append(td.text)
                elif t == 10:

                    lst_time_10.append(td.text)
                elif t == 11:

                    lst_time_11.append(td.text)
                elif t == 12:

                    lst_time_12.append(td.text)
                elif t == 13:

                    lst_time_13.append(td.text)
                elif t == 14:

                    lst_time_14.append(td.text)
                elif t == 15:

                    lst_time_15.append(td.text)
                elif t == 16:

                    lst_time_16.append(td.text)
                elif t == 17:

                    lst_time_17.append(td.text)
                elif t == 18:

                    lst_time_18.append(td.text)
                elif t == 19:

                    lst_time_19.append(td.text)
                elif t == 20:

                    lst_time_20.append(td.text)
                elif t == 21:

                    lst_time_21.append(td.text)
                elif t == 22:

                    lst_time_22.append(td.text)
                elif t == 23:

                    lst_time_23.append(td.text)
                elif t == 24:

                    lst_time_24.append(td.text)
                elif t == 25:

                    lst_time_25.append(td.text)
                elif t == 26:

                    lst_time_26.append(td.text)
                elif t == 27:

                    lst_time_27.append(td.text)
                elif t == 28:

                    lst_time_28.append(td.text)
                elif t == 29:

                    lst_time_29.append(td.text)
                elif t == 0:

                    lst_time_0.append(td.text)

                # print('dd.410..')

                # lst_link_wb = pd.Series(lst_wb)
                # lst_link = pd.Series(lst_dd)
                # list转为dataframe
            lst_code.append(code)

        except:
            print('error....')
            continue
    df_table = pd.DataFrame()
    # 添加url列

    df_table['wb'] = lst_wb
    df_table['wc'] = lst_wc
    df_table['lst_sell5_sell5'] = lst_sell5_sell5
    df_table['lst_sell5_sell5_quant'] = lst_sell5_sell5_quant
    df_table['lst_sell5_sell5_num'] = lst_sell5_sell5_num
    df_table['lst_sell5_sell4'] = lst_sell5_sell4
    df_table['lst_sell5_sell4_quant'] = lst_sell5_sell4_quant
    df_table['lst_sell5_sell4_num'] = lst_sell5_sell4_num
    df_table['lst_sell5_sell3'] = lst_sell5_sell3
    df_table['lst_sell5_sell3_quant'] = lst_sell5_sell3_quant
    df_table['lst_sell5_sell3_num'] = lst_sell5_sell3_num
    df_table['lst_sell5_sell2'] = lst_sell5_sell2
    df_table['lst_sell5_sell2_quant'] = lst_sell5_sell2_quant
    df_table['lst_sell5_sell2_num'] = lst_sell5_sell2_num
    df_table['lst_sell5_sell1'] = lst_sell5_sell1
    df_table['lst_sell5_sell1_quant'] = lst_sell5_sell1_quant
    df_table['lst_sell5_sell1_num'] = lst_sell5_sell1_num
    df_table['lst_sell5_buy5'] = lst_sell5_buy5
    df_table['lst_sell5_buy5_quant'] = lst_sell5_buy5_quant
    df_table['lst_sell5_buy5_num'] = lst_sell5_buy5_num
    df_table['lst_sell5_buy4'] = lst_sell5_buy4
    df_table['lst_sell5_buy4_quant'] = lst_sell5_buy4_quant
    df_table['lst_sell5_buy4_num'] = lst_sell5_buy4_num
    df_table['lst_sell5_buy3'] = lst_sell5_buy3
    df_table['lst_sell5_buy3_quant'] = lst_sell5_buy3_quant
    df_table['lst_sell5_buy3_num'] = lst_sell5_buy3_num
    df_table['lst_sell5_buy2'] = lst_sell5_buy2
    df_table['lst_sell5_buy2_quant'] = lst_sell5_buy2_quant
    df_table['lst_sell5_buy2_num'] = lst_sell5_buy2_num
    df_table['lst_sell5_buy1'] = lst_sell5_buy1
    df_table['lst_sell5_buy1_quant'] = lst_sell5_buy1_quant
    df_table['lst_sell5_buy1_num'] = lst_sell5_buy1_num
    df_table['lst_det_np'] = lst_det_np
    df_table['lst_det_jj'] = lst_det_jj
    df_table['lst_det_zf'] = lst_det_zf
    df_table['lst_det_zd'] = lst_det_zd
    df_table['lst_det_zs'] = lst_det_zs
    df_table['lst_det_je'] = lst_det_je
    df_table['lst_det_zhenf'] = lst_det_zhenf
    df_table['lst_det_lb'] = lst_det_lb
    df_table['lst_det_zg'] = lst_det_zg
    df_table['lst_det_zuid'] = lst_det_zuid
    df_table['lst_det_jk'] = lst_det_jk
    df_table['lst_det_zuos'] = lst_det_zuos
    df_table['lst_det_wp'] = lst_det_wp
    df_table['lst_det_neip'] = lst_det_neip
    df_table['time_0'] = lst_time_0
    df_table['time_1'] = lst_time_1
    df_table['time_2'] = lst_time_2
    df_table['time_3'] = lst_time_3
    df_table['time_4'] = lst_time_4
    df_table['time_5'] = lst_time_5
    df_table['time_6'] = lst_time_6
    df_table['time_7'] = lst_time_7
    df_table['time_8'] = lst_time_8
    df_table['time_9'] = lst_time_9
    df_table['time_10'] = lst_time_10
    df_table['time_11'] = lst_time_11
    df_table['time_12'] = lst_time_12
    df_table['time_13'] = lst_time_13
    df_table['time_14'] = lst_time_14
    df_table['time_15'] = lst_time_15
    df_table['time_16'] = lst_time_16
    df_table['time_17'] = lst_time_17
    df_table['time_18'] = lst_time_18
    df_table['time_19'] = lst_time_19
    df_table['time_20'] = lst_time_20
    df_table['time_21'] = lst_time_21
    df_table['time_22'] = lst_time_22
    df_table['time_23'] = lst_time_23
    df_table['time_24'] = lst_time_24
    df_table['time_25'] = lst_time_25
    df_table['time_26'] = lst_time_26
    df_table['time_27'] = lst_time_27
    df_table['time_28'] = lst_time_28
    df_table['time_29'] = lst_time_29
    df_table['code'] = lst_code
    # df_table['timebs'] = lst_bs
    pd.set_option('display.max_columns', None)
    daily_kzz = DB_CONN['daily_kzz']
    update_requests = []
    df_table.index.name = 'index'
    print(df_table.head())
    df_tablegroupby=df_table[['code', 'wc', 'time_28']].groupby(['code', 'time_28'], as_index=False).max()
    print(df_table[['code', 'wc', 'time_28']].groupby(['code', 'time_28'], as_index=False).max())
    print('tradedate650..')
    df_tablemax=pd.merge(df_tablegroupby,df_table,on=['code', 'time_28'],how = 'left')
    df_tabledrop=df_tablemax.drop_duplicates()
    print(df_tablemax.drop_duplicates())
    print('tradedate..')
    print(df_tabledrop)
    #time.sleep(30)
    # 将DataFrame中的行情数据，生成更新数据的请求
    i = 0
    for df_index in df_tabledrop.index:
        i += 1
        print('指数总数=')
        print(len(df_tabledrop.index))
        print('剩余次数=')
        print(len(df_table.index) - i)
        doc = dict(df_tabledrop.loc[df_index])
        update_requests.append(
            UpdateOne(
                {'code': doc['code'], 'trade_date': doc['time_28']},
                {'$set': doc},
                upsert=True)
        )
        # 如果写入的请求列表不为空，则保存都数据库中
        if len(update_requests) > 0:
            # 批量写入到数据库中，批量写入可以降低网络IO，提高速度
            update_result = daily_kzz.bulk_write(update_requests, ordered=False)
            print('保存日线数据，代码： %s, 插入：%4d条, 更新：%4d条' %
                  (code, update_result.upserted_count, update_result.modified_count),
                  flush=True)

