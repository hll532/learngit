#  -*- coding: utf-8 -*-

import sys
import zhuanzhai
import re
from selenium import webdriver
from scrapy.selector import Selector
from PyQt5.QtWidgets import QApplication, QMainWindow
from PyQt5.QtCore import pyqtSignal, QThread, QTimer
timer = QTimer()
selected_bond_code = []
selected_bond_name = []
selected_bond_price = []
selected_bond_rate = []
selected_stock_code = []
selected_stock_name = []
selected_stock_price = []
selected_stock_rate = []
j = 0




class MyWindows(QMainWindow, zhuanzhai.Ui_MainWindow):
    def __init__(self):
        super(MyWindows, self).__init__()
        self.setupUi(self)
        self.thread = WorkThread()
        self.pushButton.clicked.connect(self.select_func)#点击按钮触发select_func函数进行股票的筛选
        self.thread.signal.connect(self.Printf)#筛选进程结束调用Printf函数将所得数据输出

    # 进行股票筛选
    def select_func(self):
        self.textBrowser.clear()#每次点击‘筛选’按钮后，将TextBrowser原有的内容清空
        self.thread.data = self.lineEdit.text()#从UI界面获取lineEdit中用户输入的涨幅
        self.thread.start()  # 启动线程

    #向TextBrowser输出数据
    def Printf(self, selected_bond_code):
        global j#将j定义为全局变量，再次调用printf函数时，j从原值继续递增
        while j < len(selected_bond_code):
            self.textBrowser.append("转债代码："+selected_bond_code[j])#利用append方法而不是setText，后者会覆盖原有数据，而前者不会
            self.textBrowser.append("转债名称："+selected_bond_name[j])
            self.textBrowser.append("最新价："+selected_bond_price[j])
            self.textBrowser.append("涨跌幅："+selected_bond_rate[j])
            self.textBrowser.append("正股代码："+selected_stock_code[j])
            self.textBrowser.append("正股名称："+selected_stock_name[j])
            self.textBrowser.append("最新价："+selected_stock_price[j])
            self.textBrowser.append("涨跌幅："+selected_stock_rate[j])
            self.textBrowser.append("---------------------------------")
            j = j+1


class WorkThread(QThread):
    signal = pyqtSignal(list)  # 括号里填写信号传递的参数类型，本例中为获取到的转债代码列表

    def __init__(self):
        super(WorkThread, self).__init__()

    def run(self):
        browser = webdriver.Chrome(executable_path="D:/Anaconda/chromedriver.exe")#获取本地Chromedriver的存储路径
        browser.get("http://quote.eastmoney.com/center/fullscreenlist.html#convertible_comparison")#需爬取界面的网址
        t_selector = Selector(text=browser.page_source)
        all_page = t_selector.xpath('//*[@id="common_table_paginate"]/span[1]/a[5]/text()').extract()[0]#获取总页数，为之后翻页遍历所有页提供终止条件
        count = 0
        while count < int(all_page):
            t_selector = Selector(text=browser.page_source)
            bond_code = t_selector.css("td:nth-child(2)  a::text").extract()#通过css选择器获取所需内容并存入中转列表中
            bond_name = t_selector.css("td:nth-child(3)  a::text").extract()
            bond_price = t_selector.css("td:nth-child(4)  span::text").extract()
            bond_rate = t_selector.css("td:nth-child(5)  span::text").extract()
            stock_code = t_selector.css("td:nth-child(7)  a::text").extract()
            stock_name = t_selector.css("td:nth-child(8)  a::text").extract()
            stock_price = t_selector.css("td:nth-child(9)  span::text").extract()
            stock_rate = t_selector.css("td:nth-child(10)  span::text").extract()

            i = 0
            while i < len(stock_rate):
                re_stock_rate = re.match(r"(.*)%", stock_rate[i])#利用正则表达式进行匹配，语法re.match(r"正则表达式",需匹配字符串)
                if (float(re_stock_rate.group(1)) > float(self.data)):#将正股涨幅与用户输入的预期涨幅相比较，若大于这个值，则将相关信息存入对应的结果列表中
                    selected_bond_code.append(bond_code[i])
                    selected_bond_name.append(bond_name[i])
                    selected_bond_price.append(bond_price[i])
                    selected_bond_rate.append(bond_rate[i])
                    selected_stock_code.append(stock_code[i])
                    selected_stock_name.append(stock_name[i])
                    selected_stock_price.append(stock_price[i])
                    selected_stock_rate.append(stock_rate[i])
                i += 1

            self.signal.emit(selected_bond_code)#向UI进程传递结果
            browser.find_element_by_css_selector('.next').click()#获取下一页并点击
            count += 1
            self.sleep(1)


if __name__ == '__main__':#程序入口
    app = QApplication(sys.argv)
    mywindow = MyWindows()
    mywindow.show()
    sys.exit(app.exec_())

