#  -*- coding: utf-8 -*-

"""
普量学院量化投资课程系列案例源码包
普量学院版权所有
仅用于教学目的，严禁转发和用于盈利目的，违者必究
©Plouto-Quants All Rights Reserved

普量学院助教微信：niuxiaomi3
"""
import time
import json
import urllib3
import urllib.request
from pymongo import UpdateOne
import urllib
from database import DB_CONN
from stock_util import get_all_codes
from selenium import webdriver
from selenium.webdriver.firefox.options import Options
from selenium.webdriver.common.by import By
import pandas as pd
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.support.wait import WebDriverWait
import time

"""
抓取财报数据，主要关注EPS、公告日期、报告期
"""
#user_agent = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36'
browser = webdriver.Chrome()
opt = Options()
#opt = webdriver.ChromeOptions()
    # 浏览器不提供可视化界面。Linux下如果系统不支持可视化不加这条会启动失败(无界面运行主要是该设置)
#opt.add_argument('--headless')
#browser=webdriver.Firefox(options=opt)
#browser = webdriver.PhantomJS()
browser.maximize_window()  # 最大化窗口,可以选择设置
wait = WebDriverWait(browser, 10)

url = 'http://data.eastmoney.com/bbsj/201806/lrb.html'
browser.get(url)

pagebox=browser.find_element(By.CLASS_NAME, 'pagerbox')
pageboxnum = pagebox.find_elements(By.TAG_NAME,"a")
print('pagge')
print(pageboxnum)
lst = []
 # 存储为list
for td in pageboxnum:
    try:
        lst.append(int(td.text))
    except:
        continue
print(max(lst))  # 输出表格内容

time.sleep(30)
#document.querySelector("#dataview > div.dataview-pagination.tablepager > div.pagerbox")

element = browser.find_element(By.CLASS_NAME, 'dataview-body')  # 定位表格，element是WebElement类型
#确定行
#dataview > div.dataview-center > div.dataview-body > table
#dataview > div.dataview-center > div.dataview-body > table > tbody > tr:nth-child(1)
td_content = element.find_elements(By.TAG_NAME,"td") # 进一步定位到表格内容所在的td节点
print('row...')
print(len(td_content))
# 确定表格列数
#element_tr = browser.find_element(By.TAG_NAME, 'tr')  # 定位表格，element是WebElement类型
cols = len(element.find_elements(By.CSS_SELECTOR,'tr:nth-child(1) td'))
print('col..')
print(cols)




lst = []
 # 存储为list
for td in td_content:
    lst.append(td.text)
print(lst)  # 输出表格内容



# 通过定位一行td的数量，可获得表格的列数，然后将list拆分为对应列数的子list

lst = [lst[i:i + cols] for i in range(0, len(lst), cols)]
print(lst)
# 原网页中打开"详细"链接可以查看更详细的数据，这里我们把url提取出来，方便后期查看
lst_link = []

links = element.find_elements(By.CSS_SELECTOR,'a.red')
##dataview > div.dataview-center > div.dataview-body > table > tbody > tr:nth-child(1) > td:nth-child(4) > a.red
print(links)

for link in links:
    url = link.get_attribute('href')
    lst_link.append(url)
print(lst_link)
print('lst_link')
lst_link = pd.Series(lst_link)
# list转为dataframe
df_table = pd.DataFrame(lst)
# 添加url列
df_table['url'] = lst_link
print(df_table.head())  # 查看DataFrame

#start_page = int(input('请输入下载起始页数：\n'))
#nums = input('请输入要下载的页数，（若需下载全部则按回车）：\n')


'''
def index_page(page):
    try:
        browser.get('http://data.eastmoney.com/bbsj/201806/lrb.html')
        print('正在爬取第： %s 页' % page)
        wait.until(
            EC.presence_of_element_located((By.CLASS_NAME, 'dataview-body')))
        #隐士等待；driver.implicitly_wait(30)
        # 判断是否是第1页，如果大于1就输入跳转，否则等待加载完成。
        if page > 1:
            # 确定页数输入框
            print('page..')
            time.sleep(20)
            input = wait.until(EC.presence_of_element_located(
                (By.XPATH, '//*[@id="PageContgopage"]')))
            input.click()
            input.clear()
            input.send_keys(page)
            submit = wait.until(EC.element_to_be_clickable(
                (By.CSS_SELECTOR, '#PageCont > a.btn_link')))
            submit.click()
            time.sleep(2)
        # 确认成功跳转到输入框中的指定页
        wait.until(EC.text_to_be_present_in_element(
            (By.CSS_SELECTOR, '#PageCont > span.at'), str(page)))
    except Exception:
        return None


for page in range(1,5):  # 测试翻4页
        index_page(page)
print(df_table['url'])
'''


print('time.sleeping....')
time.sleep(30)
#url = 'https://movie.douban.com/tag/#/'
#req = urllib.request.Request(url,headers=headers)
#res = urllib.request.urlopen(req)
#content = res.read().decode('utf8')
#dcontent = json.loads(content)
#for item in dcontent['data']:
#	print (item['title'])

def crawl_finance_report():
    # 先获取所有的股票列表
    codes = get_all_codes()

    # 创建连接池
    #conn_pool = urllib3.PoolManager()

    # 抓取的财务地址，scode为股票代码
    #url = 'https://datacenter-web.eastmoney.com/api/data/v1/get?'\
    #        'callback=jQuery1123008616927366860194_1641994023509&'\
    #        'sortColumns=REPORTDATE&sortTypes=1&pageSize=50&'\
    #        'pageNumber=1&columns=ALL&filter=(SECURITY_CODE%3D%22836106%22)'\
    #      '&reportName=RPT_LICO_FN_CPD'
    #headers = {
    #    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1;WOW64) AppleWebKit/537.36 (KHTML,like GeCKO) Chrome/45.0.2454.85 Safari/537.36 115Broswer/6.0.3',
    #    'Referer': 'https://movie.douban.com/', 'Connection': 'keep-alive'}

    #url = 'http://dcfm.eastmoney.com//em_mutisvcexpandinterface/api/js/get?' \
    #      'type=YJBB20_YJBB&token=70f12f2f4f091e459a279469fe49eca5&st=reportdate&sr=-1' \
    #      '&filter=(scode={0})&p={page}&ps={pageSize}&js={"pages":(tp),"data":%20(x)}'
    #http://quote.eastmoney.com/center/gridlist.html#hs_a_board

    #url = 'https://data.eastmoney.com/bbsj/yjbb/{0}.html'
    # 循环抓取所有股票的财务信息
    for code in codes:
        # 替换股票代码，抓取该只股票的财务数据
        code=code.replace('.SZ', '')
        print('code')
        print(code.replace('.SZ', ''))
        print('url')
        print(url.replace('{0}', code))

        response = conn_pool.request('GET', url.replace('{0}', code))
        #print(response.status, response.data.decode('utf-8'))  # 获得状态码, html源码(utf-8解码)
        # 解析抓取结果
        print(response.data.decode('utf-8'))
        print(type(response.data.decode('utf-8')))
        result = json.loads(response.data.decode('utf-8'))
        print('result54...')
        # 取出数据
        reports = result['data']

        # 更新数据库的请求列表
        update_requests = []
        # 循环处理所有报告数据
        for report in reports:
            doc = {
                # 报告期
                'report_date': report['reportdate'][0:10],
                # 公告日期
                'announced_date': report['latestnoticedate'][0:10],
                # 每股收益
                'eps': report['basiceps'],
                'code': code
            }

            # 将更新请求添加到列表中，更新时的查询条件为code、report_date，为了快速保存数据，需要增加索引
            # db.finance_report.createIndex({'code':1, 'report_date':1})
            update_requests.append(
                UpdateOne(
                    {'code': code, 'report_date': doc['report_date']},
                    # upsert=True保证了如果查不到数据，则插入一条新数据
                    {'$set': doc}, upsert=True))

        # 如果更新数据的请求列表不为空，则写入数据库
        if len(update_requests) > 0:
            # 采用批量写入的方式，加快保存速度
            update_result = DB_CONN['finance_report'].bulk_write(update_requests, ordered=False)
            print('股票 %s, 财报，更新 %d, 插入 %d' %
                  (code, update_result.modified_count, update_result.upserted_count))


if __name__ == "__main__":
    crawl_finance_report()
