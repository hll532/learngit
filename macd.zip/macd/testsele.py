#  -*- coding: utf-8 -*-

from selenium import webdriver
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait
import time
import pandas as pd
import os

chrome_options = webdriver.ChromeOptions()
#chrome_options.add_argument('--headless')
browser = webdriver.Chrome(options=chrome_options)
# browser = webdriver.PhantomJS() # 会报警高提示不建议使用phantomjs，建议chrome添加无头
browser.maximize_window()  # 最大化窗口
wait = WebDriverWait(browser, 10)

browser.get('http://quote.eastmoney.com/bond/sz128111.html')
#body > div:nth-child(7) > div.fr.side.side_right > div:nth-child(1) > div.info_list > table:nth-child(1)
element = browser.find_element(By.CSS_SELECTOR, 'body > div:nth-child(7) >'
                                              ' div.fr.side.side_right >'
                                              ' div:nth-child(1) >'
                                              ' div.info_list >'
                                              ' table:nth-child(1)')
td_content = element.find_elements(By.TAG_NAME, "td")  # 进一步定位到表格内容所在的td节点
print('row...')
print(len(td_content))
print(td_content)
    # 提取表格内容td
    #td_content = element.find_elements_by_tag_name("td")
lst_wb = []
for td in td_content:
    print(td.text) # str
    lst_wb.append(td.text)
print('row.68..')

##sell_table#sell_table body > div:nth-child(7) > div.fr.side.side_right > div:nth-child(1) > div.info_list > table:nth-child(1)
element = browser.find_element(By.CSS_SELECTOR, '#sell_table#sell_table')
td_content = element.find_elements(By.TAG_NAME, "td")  # 进一步定位到表格内容所在的td节点
print('row...')
print(len(td_content))
print(td_content)
    # 提取表格内容td
    #td_content = element.find_elements_by_tag_name("td")
lst_sell5 = []
for td in td_content:
    print(td.text) # str
    lst_sell5.append(td.text)
print('row.68..')

##buy_table#buy_table
element = browser.find_element(By.CSS_SELECTOR, '#buy_table#buy_table')
td_content = element.find_elements(By.TAG_NAME, "td")  # 进一步定位到表格内容所在的td节点
print('row...')
print(len(td_content))
print(td_content)
    # 提取表格内容td
    #td_content = element.find_elements_by_tag_name("td")
lst_buy5 = []
for td in td_content:
    print(td.text) # str
    lst_buy5.append(td.text)
print('row.68..')

#body > div:nth-child(7) > div.fr.side.side_right > div:nth-child(1) > div.box-x1.line24 > table
element = browser.find_element(By.CSS_SELECTOR, 'body > div:nth-child(7) >'
                                                ' div.fr.side.side_right >'
                                                ' div:nth-child(1) >'
                                                ' div.box-x1.line24 > table')
td_content = element.find_elements(By.TAG_NAME, "td")  # 进一步定位到表格内容所在的td节点
print('row...')
print(len(td_content))
print(td_content)
    # 提取表格内容td
    #td_content = element.find_elements_by_tag_name("td")
lst_det = []
for td in td_content:
    print(td.text) # str
    lst_det.append(td.text)
print('row.68..')

##deal_detail
element = browser.find_element(By.CSS_SELECTOR, '#deal_detail')
print('element')
print(element)

td_content = element.find_elements(By.TAG_NAME, "td")  # 进一步定位到表格内容所在的td节点
print('tdcontent')
print(td_content)
print('row...')
print(len(td_content))
print(td_content)
    # 提取表格内容td
    #td_content = element.find_elements_by_tag_name("td")
lst_dd = []
for td in td_content:
    print(td.text) # str
    lst_dd.append(td.text)
print('row.68..')






